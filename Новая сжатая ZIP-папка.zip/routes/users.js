const usersRouter = require('express').Router();
const { getUsers, getProfile, createUser } = require('../controllers/users');

usersRouter.get('/users', getUsers);
usersRouter.get('/users/:id', getProfile);
usersRouter.post('/users', createUser);

module.exports = usersRouter;
